package com.piotrholda.spring.webflux.jwt;

record LoginRequest(String username, String password) {
}
