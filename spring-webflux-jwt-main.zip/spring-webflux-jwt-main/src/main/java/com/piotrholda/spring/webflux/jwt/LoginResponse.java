package com.piotrholda.spring.webflux.jwt;

record LoginResponse(String token) {
}
