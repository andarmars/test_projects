Spring Boot WebFlux with JWT Authentication

Medium article: https://medium.com/@pholda_25540/spring-boot-webflux-with-jwt-authentication-94d25b4f0794