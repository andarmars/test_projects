package com.codersee.jwtauth

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class JwtAuthApplicationTests {

	@Test
	fun contextLoads() {
	}

}
