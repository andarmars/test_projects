package com.codersee.jwtauth.controller.auth

data class TokenResponse(
  val token: String
)