package com.codersee.jwtauth.controller.auth

data class RefreshTokenRequest(
  val token: String
)